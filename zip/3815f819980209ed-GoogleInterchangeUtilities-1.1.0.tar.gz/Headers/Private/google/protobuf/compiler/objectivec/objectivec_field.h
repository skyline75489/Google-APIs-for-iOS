// Protocol Buffers - Google's data interchange format
// Copyright 2008 Google Inc.
// http://code.google.com/p/protobuf/
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Author: kenton@google.com (Kenton Varda)
//  Based on original Protocol Buffers design by
//  Sanjay Ghemawat, Jeff Dean, and others.

#ifndef GOOGLE_PROTOBUF_COMPILER_OBJECTIVEC_FIELD_H__
#define GOOGLE_PROTOBUF_COMPILER_OBJECTIVEC_FIELD_H__

#include <map>
#include <string>
#include <google/protobuf/compiler/objectivec/objectivec_helpers.h>
#include <google/protobuf/stubs/common.h>
#include <google/protobuf/descriptor.h>

namespace google {
namespace protobuf {
  namespace io {
    class Printer;             // printer.h
  }
}

namespace protobuf {
namespace compiler {
namespace objectivec {

class FieldGenerator {
 public:
  FieldGenerator(const FieldDescriptor* descriptor,
                 const CompilerOptions options);
  virtual ~FieldGenerator();

  virtual void GenerateFieldHeader(io::Printer* printer) const = 0;
  virtual void GeneratePropertyHeader(io::Printer* printer) const = 0;


  virtual void GenerateSynthesizeSource(io::Printer* printer) const = 0;
  virtual void GenerateFieldDescription(io::Printer* printer) const = 0;

  bool needs_textformat_name_support() const {
    const string& field_flags = variables_.find("fieldflags")->second;
    return field_flags.find("PBFieldTextFormatNameCustom") != string::npos;
  }
  string generated_objc_name() const { return variables_.find("name")->second; }
  string raw_field_name() const { return variables_.find("raw_field_name")->second; }

  void PrintFieldOptions(io::Printer* printer,
                         const string& structure_element_name) const;

 protected:
  const FieldDescriptor* descriptor_;
  const CompilerOptions compiler_options_;
  map<string,string> variables_;

 private:
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(FieldGenerator);
};

// Convenience class which constructs FieldGenerators for a Descriptor.
class FieldGeneratorMap {
 public:
  FieldGeneratorMap(const Descriptor* descriptor,
                    const CompilerOptions options);
  ~FieldGeneratorMap();

  const FieldGenerator& get(const FieldDescriptor* field) const;
  const FieldGenerator& get_extension(int index) const;

 private:
  const Descriptor* descriptor_;
  scoped_array<scoped_ptr<FieldGenerator> > field_generators_;
  scoped_array<scoped_ptr<FieldGenerator> > extension_generators_;

  static FieldGenerator* MakeGenerator(const FieldDescriptor* field,
                                       const CompilerOptions options);

  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(FieldGeneratorMap);
};
}  // namespace objectivec
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#endif  // GOOGLE_PROTOBUF_COMPILER_OBJECTIVEC_FIELD_H__
