// Protocol Buffers - Google's data interchange format
// Copyright 2008 Google Inc.
// http://code.google.com/p/protobuf/
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Author: kenton@google.com (Kenton Varda)
//  Based on original Protocol Buffers design by
//  Sanjay Ghemawat, Jeff Dean, and others.

#ifndef GOOGLE_PROTOBUF_COMPILER_OBJECTIVEC_HELPERS_H__
#define GOOGLE_PROTOBUF_COMPILER_OBJECTIVEC_HELPERS_H__

#include <string>
#include <vector>

#include <google/protobuf/descriptor.h>

namespace google {
namespace protobuf {
namespace compiler {
namespace objectivec {

// Converts the field's name to camel-case, e.g. "foo_bar_baz" becomes
// "fooBarBaz" or "FooBarBaz", respectively.
string UnderscoresToCamelCase(const FieldDescriptor* field);
string UnderscoresToCapitalizedCamelCase(const FieldDescriptor* field);

// Reverse of the above.
string UnCamelCaseFieldName(const string& name, const FieldDescriptor* field);

// Reverse what an enum does.
string UnCamelCaseEnumName(const string& name);

// Similar, but for method names.  (Typically, this merely has the effect
// of lower-casing the first letter of the name.)
string UnderscoresToCamelCase(const MethodDescriptor* method);

// Strips ".proto" or ".protodevel" from the end of a filename.
string StripProto(const string& filename);

// Returns true if the name requires a ns_returns_not_retained attribute applied
// to it.
bool IsRetainedName(const string& name);

// Returns true if the name starts with "init" and will need to have special
// handling under ARC.
bool IsInitName(const string& name);

//
bool IsBootstrapFile(const FileDescriptor* file);

// Gets the name of the file we're going to generate (sans the .pb.h
// extension).  This does not include the path to that file.
string FileName(const FileDescriptor* file);

// Gets the path of the file we're going to generate (sans the .pb.h
// extension).  The path will be dependent on the objectivec package
// declared in the proto package.
string FilePath(const FileDescriptor* file);

// Gets the name of the root class we'll generate in the file.  This class
// is not meant for external consumption, but instead contains helpers that
// the rest of the the classes need
string FileClassName(const FileDescriptor* file);

// Attempts to get the URL in Google Code Search for file. It returns our
// best guess at a CodeSearch URL for the file.
string LikelyCodeSearchURL(const FileDescriptor* file);

// These return the fully-qualified class name corresponding to the given
// descriptor.
string ClassName(const Descriptor* descriptor);
string ClassName(const EnumDescriptor* descriptor);
string ClassName(const ServiceDescriptor* descriptor);

// Returns the fully-qualified name of the enum value corresponding to the
// the descriptor.
string EnumValueName(const EnumValueDescriptor* descriptor);

// Returns the name of the enum value corresponding to the descriptor.
string EnumValueShortName(const EnumValueDescriptor* descriptor);

string SafeName(const string& name);

enum ObjectiveCType {
  OBJECTIVECTYPE_INT32,
  OBJECTIVECTYPE_UINT32,
  OBJECTIVECTYPE_INT64,
  OBJECTIVECTYPE_UINT64,
  OBJECTIVECTYPE_FLOAT,
  OBJECTIVECTYPE_DOUBLE,
  OBJECTIVECTYPE_BOOLEAN,
  OBJECTIVECTYPE_STRING,
  OBJECTIVECTYPE_DATA,
  OBJECTIVECTYPE_ENUM,
  OBJECTIVECTYPE_MESSAGE
};

enum {
  // Available: 1 << 0
  DeprecatedAnnotateOn = 1 << 1,
  DeprecatedRemoveOn = 1 << 2,
  DefineBuildersOn = 1 << 3,
  // Available: 1 << 4,
  // Are we going to generate enum descriptors.
  GenerateEnumDescriptorsOn = 1 << 5,
  // Are we going to generate enum names. If GenerateEnumDescriptorsOn is false
  // that implies that GenerateEnumNamesOn is false as well.
  GenerateEnumNamesOn = 1 << 6,
  UseObjcHeaderNamesOn = 1 << 7,
};
typedef unsigned int CompilerOptions;
const CompilerOptions kCompilerOptionsDefaults =
    GenerateEnumDescriptorsOn | GenerateEnumNamesOn;

string GetCapitalizedType(const FieldDescriptor* field);

string SanitizeNameForObjC(const string &input, const string &extension);
string SanitizeClassNameForObjC(string name);

ObjectiveCType GetObjectiveCType(FieldDescriptor::Type field_type);

inline ObjectiveCType GetObjectiveCType(const FieldDescriptor* field) {
  return GetObjectiveCType(field->type());
}

inline string HeaderFileNameExtension(const FileDescriptor* file,
                                      CompilerOptions options) {
  if (IsBootstrapFile(file) || !(options & UseObjcHeaderNamesOn)) {
    return "pb.h";
  } else {
    return "pbobjc.h";
  }
}

bool IsPrimitiveType(const FieldDescriptor* field);
bool IsReferenceType(const FieldDescriptor* field);

typedef enum {
  DeprecatedAnnotate,
  DeprecatedRemove,
  DeprecatedIgnore
} DeprecatedHandling;

DeprecatedHandling HowToHandleDeprecated(const CompilerOptions options);

string DefaultValue(const FieldDescriptor* field);
bool IsDefaultValueZero(const FieldDescriptor* field);

string BuildFlagsString(const vector<string> &strings);

string BuildCommentsString(const SourceLocation &location);

bool WriteClassList(string *error);
void WriteClassNameToClassList(const string &name);

// The "types" of portable proto filters entries; passed to
// WritePortableFilterToFilterList.
typedef enum {
  PortableFilterMessage,
  PortableFilterGroup,
  PortableFilterEnum,
  PortableFilterExtension,
} PortableFilterType;

bool WritePortableFilter(string *error);
void WritePortableFilterToFilterList(const string &name, PortableFilterType filter_type);

bool InitializeCompilerOptions(string *error, CompilerOptions *out_options);
bool FilterClass(const string &name, string *matched_rule);

// Generate decode data needed for ObjC's PBDecodeTextFormatName() to transform
// the input into the the expected output.
class TextFormatDecodeData {
 public:
  TextFormatDecodeData() { }

  void AddString(int32_t key,
                 const string& input_for_decode,
                 const string& desired_output);
  size_t num_entries() const { return entries_.size(); }
  string Data() const;

  static string DecodeDataForString(const string& input_for_decode,
                                    const string& desired_output);

 private:
  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(TextFormatDecodeData);

  typedef std::pair<int32_t, string> DataEntry;
  vector<DataEntry> entries_;
};

}  // namespace objectivec
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#endif  // GOOGLE_PROTOBUF_COMPILER_OBJECTIVEC_HELPERS_H__
