// Protocol Buffers - Google's data interchange format
// Copyright 2008 Google Inc.
// http://code.google.com/p/protobuf/
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Author: kenton@google.com (Kenton Varda)
//  Based on original Protocol Buffers design by
//  Sanjay Ghemawat, Jeff Dean, and others.

#ifndef GOOGLE_PROTOBUF_COMPILER_OBJECTIVEC_FILE_H__
#define GOOGLE_PROTOBUF_COMPILER_OBJECTIVEC_FILE_H__

#include <string>
#include <set>
#include <vector>
#include <google/protobuf/compiler/objectivec/objectivec_helpers.h>
#include <google/protobuf/stubs/common.h>

namespace google {
namespace protobuf {
  class FileDescriptor;        // descriptor.h
  namespace io {
    class Printer;             // printer.h
  }
}

namespace protobuf {
namespace compiler {
namespace objectivec {

class EnumGenerator;
class ExtensionGenerator;
class MessageGenerator;

class FileGenerator {
 public:
  explicit FileGenerator(const FileDescriptor* file,
                         const CompilerOptions options);
  ~FileGenerator();

  void GenerateSource(io::Printer* printer);
  void GenerateHeader(io::Printer* printer);

  const string& RootClassName() const { return root_class_name_; }
  const string Path() const;

  bool IsFiltered() const { return is_filtered_; }
  bool AreAllExtensionsFiltered() const { return all_extensions_filtered_; }
 private:
  const FileDescriptor* file_;
  string root_class_name_;
  const CompilerOptions compiler_options_;

  // Access this field through the DependencyGenerators accessor call below.
  // Do not reference it directly.
  vector<FileGenerator *> dependency_generators_;

  vector<EnumGenerator *> enum_generators_;
  vector<MessageGenerator *> message_generators_;
  vector<ExtensionGenerator *> extension_generators_;
  bool is_filtered_;
  bool all_extensions_filtered_;

  void DetermineDependencies(set<string>* dependencies);

  const vector<FileGenerator *>& DependencyGenerators();

  GOOGLE_DISALLOW_EVIL_CONSTRUCTORS(FileGenerator);
};
}  // namespace objectivec
}  // namespace compiler
}  // namespace protobuf
}  // namespace google
#endif  // GOOGLE_PROTOBUF_COMPILER_OBJECTIVEC_FILE_H__
