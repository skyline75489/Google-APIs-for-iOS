// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// This header is private to the ProtobolBuffers library and must NOT be
// included by any sources outside this library. The contents of this file are
// subject to change at any time without notice.

#import "PBArray.h"

@protocol PBMutableArrayDelegate <NSObject>

- (void)pbMutableArray:(PBMutableArray *)array
       willAddElements:(NSUInteger)count;

@end

@interface PBArray () {
 @package
  PBArrayValueType _valueType;
  NSUInteger _capacity;
  NSUInteger _count;
  // TODO(kstanger): Inline internal accesses of the data property.
  uint8_t *_data;
}

@end

inline NSUInteger PBArrayCount(PBArray *array) {
  return array ? array->_count : 0;
}

@interface PBMutableArray ()

@property (nonatomic,assign) id<PBMutableArrayDelegate> delegate;

@end

CF_EXTERN_C_BEGIN

void PBArrayAddRetainedObject(PBMutableArray *self,
                              id __attribute__((ns_consumed)) value);

CF_EXTERN_C_END
