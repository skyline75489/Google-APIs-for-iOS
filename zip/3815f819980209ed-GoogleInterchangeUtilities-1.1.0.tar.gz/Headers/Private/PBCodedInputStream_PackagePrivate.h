// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// This header is private to the ProtobolBuffers library and must NOT be
// included by any sources outside this library. The contents of this file are
// subject to change at any time without notice.

#import "PBCodedInputStream.h"

#import <libkern/OSAtomic.h>

// PBString is a string subclass that avoids the overhead of initializing
// a full NSString until it is actually needed. Lots of protocol buffers contain
// strings, and instantiating all of those strings and having them parsed to
// verify correctness when the message was being read was expensive, when many
// of the strings were never being used.
//
// Note for future-self. I tried implementing this using a NSProxy.
// Turned out the performance was horrible in client apps because folks
// like to use libraries like SBJSON that grab characters one at a time.
// The proxy overhead was a killer.
//
// If the string being stored in PBString is 7 bit ASCII (which is a subset of
// UTF-8) it will go directly into internalBuffer_. This allows us to minimize
// allocations, and do much faster access than creating an internal CFString.
// This state is initially checked by AreBytesIn7BitASCII(), and then
// checked throughout the PBString implementation by UsingInternalBuffer().
// This is a significant performance improvement when deserializing large
// proto bufs.
//
// PBString IS NOT designed for subclassing, and has some very specialized
// non-standard Objective C uses and assumptions.
@interface PBString : NSString {
  CFStringRef string_;
  unsigned char *utf8_;
  NSUInteger utf8Len_;
  OSSpinLock lock_;
  BOOL hasBOM_;

  // internalBuffer_ MUST be the last item in this class.
  unsigned char internalBuffer_[0];
}
@end

CF_EXTERN_C_BEGIN

// Returns a PBString with a +1 retain count.
PBString *PBCreatePBStringWithUTF8(const void *bytes, NSUInteger length)
     __attribute__((ns_returns_retained));

int32_t PBReadTag(PBCodedInputStream *self);
NSString *PBReadRetainedString(PBCodedInputStream *self) __attribute((ns_returns_retained));
NSData *PBReadRetainedData(PBCodedInputStream *self) __attribute((ns_returns_retained));
size_t PBPushLimit(PBCodedInputStream *self, size_t byteLimit);
void PBPopLimit(PBCodedInputStream *self, size_t oldLimit);
BOOL PBIsAtEnd(PBCodedInputStream *self);

CF_EXTERN_C_END
