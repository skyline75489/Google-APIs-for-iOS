// Copyright 2008 Cyrus Najmabadi
// Copyright 2011 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import <Foundation/Foundation.h>

#import "PBTypes.h"
#import "PBArray.h"

@class PBGeneratedMessage;
@class PBMutableArray;
@class PBFieldDescriptor;
@class PBUnknownFieldSet;

// Macros for stringifying library symbols. These are used in the generated
// PB descriptor classes wherever a library symbol name is represented as a
// string. See README.google for more information.
#define PBStringify(S) #S
#define PBStringifySymbol(S) PBStringify(S)

#define PBNSStringify(S) @#S
#define PBNSStringifySymbol(S) PBNSStringify(S)

CF_EXTERN_C_BEGIN

int64_t PBConvertDoubleToInt64(double f) __attribute__ ((const));
int32_t PBConvertFloatToInt32(float f) __attribute__ ((const));
double  PBConvertInt64ToDouble(int64_t f) __attribute__ ((const));
float   PBConvertInt32ToFloat(int32_t f) __attribute__ ((const));

int32_t PBLogicalRightShift32(int32_t value,
                              int32_t spaces) __attribute__ ((const));
int64_t PBLogicalRightShift64(int64_t value,
                              int32_t spaces) __attribute__ ((const));

int32_t PBDecodeZigZag32(uint32_t n) __attribute__ ((const));
int64_t PBDecodeZigZag64(uint64_t n) __attribute__ ((const));

uint32_t PBEncodeZigZag32(int32_t n) __attribute__ ((const));
uint64_t PBEncodeZigZag64(int64_t n) __attribute__ ((const));

BOOL PBTypeIsObject(PBType type) __attribute__ ((const));
BOOL PBTypeIsMessage(PBType type) __attribute__ ((const));
BOOL PBTypeIsEnum(PBType type) __attribute__ ((const));

BOOL PBGetHasIvar(PBGeneratedMessage* self, uint32_t index);
void PBSetHasIvar(PBGeneratedMessage *self, uint32_t idx, BOOL value);

// Returns an empty NSData to assign to byte fields when you wish
// to assign them to empty. Prevents allocating a lot of little [NSData data]
// objects.
NSData *PBEmptyNSData(void) __attribute__ ((pure));

PBArrayValueType PBArrayValueTypeForPBType(PBType type);

// Getters and Setters for ivars named |name| from instance self.
#define IVAR_ACCESSORS_DECL(NAME, TYPE) \
  TYPE PBGet##NAME##IvarWithField(PBGeneratedMessage *self, \
                                  PBFieldDescriptor *field); \
  void PBSet##NAME##IvarWithField(PBGeneratedMessage *self, \
                                  PBFieldDescriptor *field, \
                                  TYPE value); \
  void PBSetHas##NAME##IvarWithField(PBGeneratedMessage *self, \
                                     PBFieldDescriptor *field);
IVAR_ACCESSORS_DECL(Data, NSData*)
IVAR_ACCESSORS_DECL(String, NSString*)
IVAR_ACCESSORS_DECL(Message, PBGeneratedMessage*)
IVAR_ACCESSORS_DECL(Group, PBGeneratedMessage*)
IVAR_ACCESSORS_DECL(Bool, BOOL)
IVAR_ACCESSORS_DECL(Int32, int32_t)
IVAR_ACCESSORS_DECL(SFixed32, int32_t)
IVAR_ACCESSORS_DECL(SInt32, int32_t)
IVAR_ACCESSORS_DECL(Enum, int32_t)
IVAR_ACCESSORS_DECL(UInt32, uint32_t)
IVAR_ACCESSORS_DECL(Fixed32, uint32_t)
IVAR_ACCESSORS_DECL(Int64, int64_t)
IVAR_ACCESSORS_DECL(SInt64, int64_t)
IVAR_ACCESSORS_DECL(SFixed64, int64_t)
IVAR_ACCESSORS_DECL(UInt64, uint64_t)
IVAR_ACCESSORS_DECL(Fixed64, uint64_t)
IVAR_ACCESSORS_DECL(Float, float)
IVAR_ACCESSORS_DECL(Double, double)
IVAR_ACCESSORS_DECL(Object, id)

void PBSetRetainedObjectIvarWithField(PBGeneratedMessage *self,
                                      PBFieldDescriptor *field,
                                      id __attribute__((ns_consumed)) value);

PBMutableArray *PBGetArrayIvar(PBGeneratedMessage *self, SEL _cmd);
PBMutableArray *PBGetArrayIvarWithField(PBGeneratedMessage *self,
                                        PBFieldDescriptor *field);

// PBGetObjectIvarWithField will automatically create the field (message or
// array) if it doesn't exist. PBGetObjectIvarWithFieldNoAutocreate will return
// nil.
id PBGetObjectIvarWithFieldNoAutocreate(PBGeneratedMessage *self,
                                        PBFieldDescriptor *field);

// Clears and releases the autocreated message ivar, if it's autocreated. If
// it's not set as autocreated, this method does nothing.
void PBClearAutocreatedMessageIvarWithField(PBGeneratedMessage *self,
                                            PBFieldDescriptor *field);

// Utilities for applying various functions based on Objective C types.

// A basic functor that is passed a field and a context. Returns YES
// if the calling function should continue processing, and NO if the calling
// function should stop processing.
typedef BOOL (*PBApplyFunction)(PBFieldDescriptor *field,
                                void *context);

// Functions called for various types. See ApplyFunctionsToMessageFields.
typedef enum {
  PBApplyFunctionObject,
  PBApplyFunctionBool,
  PBApplyFunctionInt32,
  PBApplyFunctionUInt32,
  PBApplyFunctionInt64,
  PBApplyFunctionUInt64,
  PBApplyFunctionFloat,
  PBApplyFunctionDouble,
} PBApplyFunctionOrder;

enum {
  // A count of the number of types in PBApplyFunctionOrder. Separated out
  // from the PBApplyFunctionOrder enum to avoid warnings regarding not handling
  // PBApplyFunctionCount in switch statements.
  PBApplyFunctionCount = PBApplyFunctionDouble + 1
};

typedef PBApplyFunction PBApplyFunctions[PBApplyFunctionCount];


// Functions called for various types.
// See ApplyStrictFunctionsToMessageFields.
// They are in the same order as the PBTypes enum.
typedef PBApplyFunction PBApplyStrictFunctions[PBTypeCount];

// A macro for easily initializing a PBApplyFunctions struct
// PBApplyFunctions foo = PBAPPLY_FUNCTIONS_INIT(Foo);
#define PBAPPLY_FUNCTIONS_INIT(PREFIX) \
  { \
    PREFIX##Object,  \
    PREFIX##Bool,    \
    PREFIX##Int32,   \
    PREFIX##UInt32,  \
    PREFIX##Int64,   \
    PREFIX##UInt64,  \
    PREFIX##Float,   \
    PREFIX##Double,  \
  }

// A macro for easily initializing a PBApplyStrictFunctions struct
// PBApplyStrictFunctions foo = PBAPPLY_STRICT_FUNCTIONS_INIT(Foo);
// These need to stay in the same order as
// the PBType enum.
#define PBAPPLY_STRICT_FUNCTIONS_INIT(PREFIX) \
  { \
    PREFIX##Bool,     \
    PREFIX##Fixed32,  \
    PREFIX##SFixed32, \
    PREFIX##Float,    \
    PREFIX##Fixed64,  \
    PREFIX##SFixed64, \
    PREFIX##Double,   \
    PREFIX##Int32,    \
    PREFIX##Int64,    \
    PREFIX##SInt32,   \
    PREFIX##SInt64,   \
    PREFIX##UInt32,   \
    PREFIX##UInt64,   \
    PREFIX##Data,     \
    PREFIX##String,   \
    PREFIX##Message,  \
    PREFIX##Group,    \
    PREFIX##Enum,     \
}

// Iterates over the fields of a proto |msg| and applies the functions in
// |functions| to them with |context|. If one of the functions in |functions|
// returns NO, it will return immediately and not process the rest of the
// ivars. The types in the fields are mapped so:
// Int32, Enum, SInt32 and SFixed32 will be mapped to the int32Function,
// UInt32 and Fixed32 will be mapped to the uint32Function,
// Bytes, String, Message and Group will be mapped to the objectFunction,
// etc..
// If you require more specific mappings look at
// PBApplyStrictFunctionsToMessageFields.
void PBApplyFunctionsToMessageFields(PBApplyFunctions *functions,
                                     PBGeneratedMessage *msg,
                                     void *context);

// Iterates over the fields of a proto |msg| and applies the functions in
// |functions| to them with |context|. If one of the functions in |functions|
// returns NO, it will return immediately and not process the rest of the
// ivars. The types in the fields are mapped directly:
// Int32 -> functions[PBTypeInt32],
// SFixed32 -> functions[PBTypeSFixed32],
// etc...
// If you can use looser mappings look at PBApplyFunctionsToMessageFields.
NSUInteger PBApplyStrictFunctionsToMessageFields(PBApplyStrictFunctions *functions,
                                                 PBGeneratedMessage *msg,
                                                 NSUInteger startingIndex,
                                                 void *context);

// Applies the appropriate function in |functions| based on |field|.
// Returns the value from function(name, context).
// Throws an exception if the type is unrecognized.
BOOL PBApplyFunctionsBasedOnField(PBFieldDescriptor *field,
                                  PBApplyFunctions *functions,
                                  void *context);


// Returns an Objective C encoding for |selector|. |instanceSel| should be
// YES if it's an instance selector (as opposed to a class selector).
// |selector| must be a selector from MessageSignatureProtocol.
const char *PBMessageEncodingForSelector(SEL selector, BOOL instanceSel);

// Generates a sting that should be a valid "Text Format" for the C++ version
// of Protocol Buffers. lineIndent can be nil if no additional line indent is
// needed. The comments provide the names according to the ObjC library, they
// most likely won't exactly match the original .proto file.
NSString *PBTextFormatForMessage(PBGeneratedMessage *message,
                                 NSString *lineIndent);
NSString *PBTextFormatForUnknownFieldSet(PBUnknownFieldSet *unknownSet,
                                         NSString *lineIndent);

// Helper for text format name encoding.
// decodeData is the data describing the sepecial decodes.
// key and inputString are the input that needs decoding.
NSString *PBDecodeTextFormatName(const uint8_t *decodeData,
                                 int32_t key, NSString *inputString);

// A series of selectors that are used solely to get @encoding values
// for them by the dynamic protobuf runtime code. See
// PBMessageEncodingForSelector for details.
@protocol PBMessageSignatureProtocol
 @optional

#define MESSAGE_SIGNATURE_ENTRY(TYPE, NAME) \
- (TYPE)get##NAME; \
- (id)set##NAME:(TYPE)value; \
- (TYPE)get##NAME##AtIndex:(NSUInteger)index;

MESSAGE_SIGNATURE_ENTRY(BOOL, Bool)
MESSAGE_SIGNATURE_ENTRY(uint32_t, Fixed32)
MESSAGE_SIGNATURE_ENTRY(int32_t, SFixed32)
MESSAGE_SIGNATURE_ENTRY(float, Float)
MESSAGE_SIGNATURE_ENTRY(uint64_t, Fixed64)
MESSAGE_SIGNATURE_ENTRY(int64_t, SFixed64)
MESSAGE_SIGNATURE_ENTRY(double, Double)
MESSAGE_SIGNATURE_ENTRY(int32_t, Int32)
MESSAGE_SIGNATURE_ENTRY(int64_t, Int64)
MESSAGE_SIGNATURE_ENTRY(int32_t, SInt32)
MESSAGE_SIGNATURE_ENTRY(int64_t, SInt64)
MESSAGE_SIGNATURE_ENTRY(uint32_t, UInt32)
MESSAGE_SIGNATURE_ENTRY(uint64_t, UInt64)
MESSAGE_SIGNATURE_ENTRY(NSData*, Data)
MESSAGE_SIGNATURE_ENTRY(NSString*, String)
MESSAGE_SIGNATURE_ENTRY(PBGeneratedMessage*, Message)
MESSAGE_SIGNATURE_ENTRY(PBGeneratedMessage*, Group)
MESSAGE_SIGNATURE_ENTRY(int32_t, Enum)

#undef MESSAGE_SIGNATURE_ENTRY

- (id)getArray;
- (id)setArray:(PBArray*)array;
- (id)setClassBuilder:(id)value;
- (id)mergeClass:(id)value;

+ (id)getClassValue;
@end

CF_EXTERN_C_END
