// Copyright 2012 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import <Foundation/Foundation.h>

#import "PBMessageDescription.h"

@class PBFieldDescriptor, PBEnumDescriptor, PBArray;

@interface PBDescriptor : NSObject<NSCopying>

@property(nonatomic, readonly, retain) NSString *name;
@property(nonatomic, readonly, retain) PBArray *fields;
@property(nonatomic, readonly, retain) PBArray *enums;
@property(nonatomic, readonly, retain) PBArray *extensions;
@property(nonatomic, readonly, retain) PBArray *extensionRanges;

@property(nonatomic, readonly) size_t storageSize;
@property(nonatomic, readonly, getter = isWireFormat) BOOL wireFormat;
@property(nonatomic, readonly) Class messageClass;

// fieldDescriptions, enumDescriptions, rangeDescriptions, and
// extraTextFormatInfo have to be long lived, they are held as raw pointers.
+ (instancetype)allocDescriptorForClass:(Class)messageClass
                              rootClass:(Class)rootClass
                                 fields:(PBMessageFieldDescription *)fieldDescriptions
                             fieldCount:(NSUInteger)fieldCount
                                  enums:(PBMessageEnumDescription *)enumDescriptions
                              enumCount:(NSUInteger)enumCount
                                 ranges:(PBMessageExtensionRangeDescription *)rangeDescriptions
                             rangeCount:(NSUInteger)rangeCount
                            storageSize:(size_t)storageSize
                             wireFormat:(BOOL)wireFormat;
+ (instancetype)allocDescriptorForClass:(Class)messageClass
                              rootClass:(Class)rootClass
                                 fields:(PBMessageFieldDescription *)fieldDescriptions
                             fieldCount:(NSUInteger)fieldCount
                                  enums:(PBMessageEnumDescription *)enumDescriptions
                              enumCount:(NSUInteger)enumCount
                                 ranges:(PBMessageExtensionRangeDescription *)rangeDescriptions
                             rangeCount:(NSUInteger)rangeCount
                            storageSize:(size_t)storageSize
                             wireFormat:(BOOL)wireFormat
                    extraTextFormatInfo:(const char *)extraTextFormatInfo;

- (instancetype)initWithClass:(Class)messageClass
                       fields:(PBArray *)fields
                        enums:(PBArray *)enums
                   extensions:(PBArray *)extensions
              extensionRanges:(PBArray *)extensionRanges
                  storageSize:(size_t)storage
                   wireFormat:(BOOL)wireFormat;

- (PBFieldDescriptor *)fieldWithNumber:(uint32_t)fieldNumber;
- (PBFieldDescriptor *)fieldWithName:(NSString *)name;
- (PBEnumDescriptor *)enumWithName:(NSString *)name;
- (PBFieldDescriptor *)extensionWithNumber:(uint32_t)fieldNumber;
- (PBFieldDescriptor *)extensionWithName:(NSString *)name;

@end

@interface PBFieldDescriptor : NSObject

@property(nonatomic, readonly, retain) NSString *name;
@property(nonatomic, readonly) uint32_t number;
@property(nonatomic, readonly) PBType type;
@property(nonatomic, readonly) BOOL hasDefaultValue;
@property(nonatomic, readonly) PBValue defaultValue;
@property(nonatomic, readonly, getter=isRequired) BOOL required;
@property(nonatomic, readonly, getter=isOptional) BOOL optional;
@property(nonatomic, readonly, getter=isRepeated) BOOL repeated;
@property(nonatomic, readonly, getter=isPackable) BOOL packable;
@property(nonatomic, readonly, getter=isMessage) BOOL message;

@property(nonatomic, readonly) SEL getSel;
@property(nonatomic, readonly) size_t offset;
@property(nonatomic, readonly) uint32_t tag;
@property(nonatomic, readonly) SEL setSel;
@property(nonatomic, readonly) PBFieldOptions *fieldOptions;
@property(nonatomic, readonly) SEL hasSel;
@property(nonatomic, readonly) SEL setHasSel;
@property(nonatomic, readonly) uint32_t hasIndex;

// Message properties
@property(nonatomic, readonly, assign) Class msgClass;

// Enum properties
// enumDescriptor may be nil if the protos were compiled with the
// GenerateEnumDescriptors flag turned off.
@property(nonatomic, readonly, retain) PBEnumDescriptor *enumDescriptor;

// Single initializer
// description has to be long lived, it is held as a raw pointer.
- (instancetype)initWithFieldDescription:(PBMessageFieldDescription *)description
                               rootClass:(Class)rootClass;

- (BOOL)isValidEnumValue:(int32_t)value;

// For now, this will return nil if it doesn't know the name to use for
// TextFormat.
- (NSString *)textFormatName;

@end

@interface PBEnumValueDescriptor : NSObject

@property(nonatomic, readonly, retain) NSString *name;
@property(nonatomic, readonly) int32_t number;

// description has to be long lived, it is held as a raw pointer.
- (instancetype)initWithEnumValueDescription:(PBMessageEnumValueDescription *)description
                                      prefix:(NSString *)prefix;
@end

@interface PBEnumDescriptor : NSObject

@property(nonatomic, readonly, retain) NSString *name;
@property(nonatomic, readonly, retain) PBArray *values;
@property(nonatomic, readonly) PBEnumVerificationFunc enumVerifier;

// valueDescriptions and extraTextFormatInfo have to be long lived, they are
// held as raw pointers.
+ (instancetype)allocDescriptorForName:(NSString *)name
                                values:(PBMessageEnumValueDescription *)valueDescriptions
                            valueCount:(NSUInteger)valueCount
                          enumVerifier:(PBEnumVerificationFunc)enumVerifier;
+ (instancetype)allocDescriptorForName:(NSString *)name
                                values:(PBMessageEnumValueDescription *)valueDescriptions
                            valueCount:(NSUInteger)valueCount
                          enumVerifier:(PBEnumVerificationFunc)enumVerifier
                   extraTextFormatInfo:(const char *)extraTextFormatInfo;
+ (instancetype)descriptorForName:(const char *)name;

- (instancetype)initWithName:(NSString *)name
                      values:(PBArray *)values
                enumVerifier:(PBEnumVerificationFunc)enumVerifier;

- (PBEnumValueDescriptor *)enumValueWithNumber:(int32_t)number;
- (PBEnumValueDescriptor *)enumValueWithName:(NSString *)name;

- (NSString *)textFormatNameForEnumValue:(int32_t)number;

@end

@interface PBGeneratedEnumDescriptor : NSObject

// Return the descriptor for the enum type
+ (PBEnumDescriptor *)enumDescriptor;
- (PBEnumDescriptor *)enumDescriptor;

@end

@interface PBExtensionRange : NSObject

@property(nonatomic, readonly) uint32_t start;  // inclusive
@property(nonatomic, readonly) uint32_t end;    // exclusive

// description has to be long lived, it is held as a raw pointer.
- (instancetype)initWithRangeDescription:(PBMessageExtensionRangeDescription*)description;
@end

@interface PBExtensionDescriptor : NSObject

@property(nonatomic, readonly) uint32_t fieldNumber;
@property(nonatomic, readonly) PBType type;
@property(nonatomic, readonly, getter=isRepeated) BOOL repeated;
@property(nonatomic, readonly, getter=isPackable) BOOL packable;
@property(nonatomic, readonly, getter=isMessage) BOOL message;
@property(nonatomic, readonly, assign) Class msgClass;
@property(nonatomic, readonly) NSString *singletonName;
@property(nonatomic, readonly, retain) PBEnumDescriptor *enumDescriptor;

// description has to be long lived, it is held as a raw pointer.
- (instancetype)initWithExtensionDescription:(PBExtensionDescription *)description;
@end
