// Copyright 2008 Cyrus Najmabadi
// Copyright 2011 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef __has_feature
#define __has_feature(x) 0 // Compatibility with non-clang compilers.
#endif // __has_feature

#ifndef __has_attribute
#define __has_attribute(x) 0  // Compatibility with non-clang compilers.
#endif

#ifndef __has_extension
#define __has_extension(x) 0  // Compatibility with non-clang compilers.
#endif

#ifndef NS_RETURNS_RETAINED
#if __has_feature(attribute_ns_returns_retained)
#define NS_RETURNS_RETAINED __attribute__((ns_returns_retained))
#else
#define NS_RETURNS_RETAINED
#endif
#endif

#ifndef NS_RETURNS_NOT_RETAINED
#if __has_feature(attribute_ns_returns_not_retained)
#define NS_RETURNS_NOT_RETAINED __attribute__((ns_returns_not_retained))
#else
#define NS_RETURNS_NOT_RETAINED
#endif
#endif

#ifndef NS_UNSAFE_UNRETAINED
#if __has_feature(objc_arc)
#define NS_UNSAFE_UNRETAINED __unsafe_unretained
#else
#define NS_UNSAFE_UNRETAINED
#endif
#endif

#ifndef PB_DEPRECATED
#if __has_attribute(deprecated)
#define PB_DEPRECATED __attribute__((deprecated))
#else
#define PB_DEPRECATED
#endif
#endif

#ifndef PB_ENUM_VALUE_DEPRECATED
#if __has_extension(enumerator_attributes)
#define PB_ENUM_VALUE_DEPRECATED __attribute__((deprecated))
#else
#define PB_ENUM_VALUE_DEPRECATED
#endif
#endif

// The Objective C runtime has complete enough info that most protos don’t end
// up using this, so leaving it on is no cost or very little cost.  If you
// happen to see it causing bloat, this is the way to disable it. If you do
// need to disable it, try only disabling it for Release builds as having
// full TextFormat can be useful for debugging.
#ifndef PBOBJC_SKIP_MESSAGE_TEXTFORMAT_EXTRAS
#define PBOBJC_SKIP_MESSAGE_TEXTFORMAT_EXTRAS 0
#endif

// Most uses of protocol buffers don't need field options, by default the
// static data will be compiled out, define this to 1 to include it. The only
// time you need this is if you are doing introspection of the protocol buffers.
#ifndef PBOBJC_INCLUDE_FIELD_OPTIONS
#define PBOBJC_INCLUDE_FIELD_OPTIONS 0
#endif

// int32_t was chosen based on the fact that Protocol Buffers enums are limited
// to this range. The internal library implementation uses int32_t so by keeping
// this in sync, there are no concerns with sign extension/truncation for 64bit
// that would exist if something like NSInteger were used.
#define PB_ENUM_TYPE int32_t

// Used in the generated code to give sizes to our enums.
#define PB_ENUM(_name) NS_ENUM(PB_ENUM_TYPE, _name)

// PB_ENUM_FWD_DECLARE is used for forward declaring enums ex:
// @property (nonatomic) PB_ENUM_FWD_DECLARE(Foo_Enum) value;
// The reason to use PB_ENUM_FWD_DECLARE is that it allows us to change
// enum size types centrally (see PB_ENUM_TYPE) without changing all clients.
#ifndef PB_ENUM_FWD_DECLARE
#if __has_feature(objc_fixed_enum)
#define PB_ENUM_FWD_DECLARE(_name) enum _name : PB_ENUM_TYPE
#else
#define PB_ENUM_FWD_DECLARE(_name) COMPILER_DOES_NOT_SUPPORT_PB_ENUM_FWD_DECLARE
#endif
#endif

// The protoc-gen-objc version which works with the current version of the
// generated Objective C sources.
#define GOOGLE_PROTOBUF_PROTOC_GEN_OBJC_VERSION 304
