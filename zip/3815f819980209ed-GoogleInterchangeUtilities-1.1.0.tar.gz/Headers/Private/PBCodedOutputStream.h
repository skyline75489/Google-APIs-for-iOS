// Copyright 2008 Cyrus Najmabadi
// Copyright 2011 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import <Foundation/Foundation.h>

#import "PBTypes.h"
#import "PBWireFormat.h"

/**
 * Encodes and writes protocol message fields.
 *
 * <p>This class contains two kinds of methods:  methods that write specific
 * protocol message constructs and field types (e.g. {@link #writeTag} and
 * {@link #writeInt32}) and methods that write low-level values (e.g.
 * {@link #writeRawVarint32} and {@link #writeRawBytes}).  If you are
 * writing encoded protocol messages, you should use the former methods, but if
 * you are writing some other format of your own design, use the latter.
 *
 * <p>This class is totally unsynchronized.
 *
 * @author Cyrus Najmabadi
 */

@class PBArray;
@class PBGeneratedMessage;
@class PBUnknownFieldSet;

@interface PBCodedOutputStream : NSObject

/**
 * Creates a new stream to write into data.  Data must be sized to fit or it
 * will error when it runs out of space.
 */
+ (instancetype)streamWithData:(NSMutableData*)data;
+ (instancetype)streamWithOutputStream:(NSOutputStream*)output;
+ (instancetype)streamWithOutputStream:(NSOutputStream*)output
                            bufferSize:(size_t)bufferSize;

- (instancetype)initWithOutputStream:(NSOutputStream*)output;
- (instancetype)initWithData:(NSMutableData*)data;
- (instancetype)initWithOutputStream:(NSOutputStream*)output bufferSize:(size_t)bufferSize;
- (instancetype)initWithOutputStream:(NSOutputStream*)output data:(NSMutableData*)data;

/**
 * Flushes the stream and forces any buffered bytes to be written.  This
 * does not flush the underlying NSOutputStream.
 */
- (void)flush;

- (void)writeRawByte:(uint8_t)value;

- (void)writeTag:(uint32_t)fieldNumber format:(PBWireFormat)format;

- (void)writeRawLittleEndian32:(int32_t)value;
- (void)writeRawLittleEndian64:(int64_t)value;

/**
 * Encode and write a varint.  {@code value} is treated as
 * unsigned, so it won't be sign-extended if negative.
 */
- (void)writeRawVarint32:(int32_t)value;
- (void)writeRawVarint64:(int64_t)value;

// Note that this will truncate 64 bit values to 32.
- (void)writeRawVarintSizeTAs32:(size_t)value;

- (void)writeRawData:(NSData*)data;
- (void)writeRawPtr:(const void*)data offset:(size_t)offset length:(size_t)length;

// Write methods for types that can be in packed arrays.
#define WRITE_PACKABLE_DECLS(NAME, TYPE) \
  - (void)write##NAME:(int32_t)fieldNumber value:(TYPE)value; \
  - (void)write##NAME##s:(int32_t)fieldNumber values:(PBArray*)values tag:(uint32_t)tag; \
  - (void)write##NAME##NoTag:(TYPE)value;

// Write methods for types that aren't in packed arrays.
#define WRITE_UNPACKABLE_DECLS(NAME, TYPE) \
  - (void)write##NAME:(int32_t)fieldNumber value:(TYPE)value; \
  - (void)write##NAME##s:(int32_t)fieldNumber values:(PBArray*)values; \
  - (void)write##NAME##NoTag:(TYPE)value;

// Special write methods for Groups.
#define WRITE_GROUP_DECLS(NAME, TYPE) \
  - (void)write##NAME:(int32_t)fieldNumber value:(TYPE)value; \
  - (void)write##NAME##s:(int32_t)fieldNumber values:(PBArray*)values; \
  - (void)write##NAME##NoTag:(int32_t)fieldNumber value:(TYPE)value;

WRITE_PACKABLE_DECLS(Double, double);
WRITE_PACKABLE_DECLS(Float, float);
WRITE_PACKABLE_DECLS(UInt64, uint64_t);
WRITE_PACKABLE_DECLS(Int64, int64_t);
WRITE_PACKABLE_DECLS(Int32, int32_t);
WRITE_PACKABLE_DECLS(UInt32, uint32_t);
WRITE_PACKABLE_DECLS(Fixed64, uint64_t);
WRITE_PACKABLE_DECLS(Fixed32, uint32_t);
WRITE_PACKABLE_DECLS(SInt32, int32_t);
WRITE_PACKABLE_DECLS(SInt64, int64_t);
WRITE_PACKABLE_DECLS(SFixed64, int64_t);
WRITE_PACKABLE_DECLS(SFixed32, int32_t);
WRITE_PACKABLE_DECLS(Bool, BOOL);
WRITE_PACKABLE_DECLS(Enum, int32_t);
WRITE_UNPACKABLE_DECLS(String, NSString*);
WRITE_UNPACKABLE_DECLS(Message, PBGeneratedMessage*);
WRITE_UNPACKABLE_DECLS(Data, NSData*);
WRITE_GROUP_DECLS(Group, PBGeneratedMessage*);
WRITE_GROUP_DECLS(UnknownGroup, PBUnknownFieldSet*);


/**
 * Write a MessageSet extension field to the stream.  For historical reasons,
 * the wire format differs from normal fields.
 */
- (void)writeMessageSetExtension:(int32_t)fieldNumber value:(PBGeneratedMessage*)value;

/**
 * Write an unparsed MessageSet extension field to the stream.  For
 * historical reasons, the wire format differs from normal fields.
 */
- (void)writeRawMessageSetExtension:(int32_t)fieldNumber value:(NSData*)value;

@end

CF_EXTERN_C_BEGIN

size_t PBComputeDoubleSize(int32_t fieldNumber, double value) __attribute__ ((const));
size_t PBComputeFloatSize(int32_t fieldNumber, float value) __attribute__ ((const));
size_t PBComputeUInt64Size(int32_t fieldNumber, uint64_t value) __attribute__ ((const));
size_t PBComputeInt64Size(int32_t fieldNumber, int64_t value) __attribute__ ((const));
size_t PBComputeInt32Size(int32_t fieldNumber, int32_t value) __attribute__ ((const));
size_t PBComputeFixed64Size(int32_t fieldNumber, uint64_t value) __attribute__ ((const));
size_t PBComputeFixed32Size(int32_t fieldNumber, uint32_t value) __attribute__ ((const));
size_t PBComputeBoolSize(int32_t fieldNumber, BOOL value) __attribute__ ((const));
size_t PBComputeStringSize(int32_t fieldNumber, NSString* value) __attribute__ ((const));
size_t PBComputeGroupSize(int32_t fieldNumber, PBGeneratedMessage *value) __attribute__ ((const));
size_t PBComputeUnknownGroupSize(int32_t fieldNumber, PBUnknownFieldSet* value) __attribute__ ((const));
size_t PBComputeMessageSize(int32_t fieldNumber, PBGeneratedMessage *value) __attribute__ ((const));
size_t PBComputeDataSize(int32_t fieldNumber, NSData* value) __attribute__ ((const));
size_t PBComputeUInt32Size(int32_t fieldNumber, uint32_t value) __attribute__ ((const));
size_t PBComputeSFixed32Size(int32_t fieldNumber, int32_t value) __attribute__ ((const));
size_t PBComputeSFixed64Size(int32_t fieldNumber, int64_t value) __attribute__ ((const));
size_t PBComputeSInt32Size(int32_t fieldNumber, int32_t value) __attribute__ ((const));
size_t PBComputeSInt64Size(int32_t fieldNumber, int64_t value) __attribute__ ((const));
size_t PBComputeTagSize(int32_t fieldNumber) __attribute__ ((const));
size_t PBComputeWireFormatTagSize(int field_number, PBType type) __attribute__ ((const));

size_t PBComputeDoubleSizeNoTag(double value) __attribute__ ((const));
size_t PBComputeFloatSizeNoTag(float value) __attribute__ ((const));
size_t PBComputeUInt64SizeNoTag(uint64_t value) __attribute__ ((const));
size_t PBComputeInt64SizeNoTag(int64_t value) __attribute__ ((const));
size_t PBComputeInt32SizeNoTag(int32_t value) __attribute__ ((const));
size_t PBComputeFixed64SizeNoTag(uint64_t value) __attribute__ ((const));
size_t PBComputeFixed32SizeNoTag(uint32_t value) __attribute__ ((const));
size_t PBComputeBoolSizeNoTag(BOOL value) __attribute__ ((const));
size_t PBComputeStringSizeNoTag(NSString* value) __attribute__ ((const));
size_t PBComputeGroupSizeNoTag(PBGeneratedMessage *value) __attribute__ ((const));
size_t PBComputeUnknownGroupSizeNoTag(PBUnknownFieldSet* value) __attribute__ ((const));
size_t PBComputeMessageSizeNoTag(PBGeneratedMessage *value) __attribute__ ((const));
size_t PBComputeDataSizeNoTag(NSData* value) __attribute__ ((const));
size_t PBComputeUInt32SizeNoTag(int32_t value) __attribute__ ((const));
size_t PBComputeEnumSizeNoTag(int32_t value) __attribute__ ((const));
size_t PBComputeSFixed32SizeNoTag(int32_t value) __attribute__ ((const));
size_t PBComputeSFixed64SizeNoTag(int64_t value) __attribute__ ((const));
size_t PBComputeSInt32SizeNoTag(int32_t value) __attribute__ ((const));
size_t PBComputeSInt64SizeNoTag(int64_t value) __attribute__ ((const));

// Note that this will calculate the size of 64 bit values truncated to 32.
size_t PBComputeSizeTSizeAsInt32NoTag(size_t value) __attribute__ ((const));


/**
 * Compute the number of bytes that would be needed to encode a varint.
 * {@code value} is treated as unsigned, so it won't be sign-extended if
 * negative.
 */
size_t PBComputeRawVarint32Size(int32_t value) __attribute__ ((const));
size_t PBComputeRawVarint64Size(int64_t value) __attribute__ ((const));

// Note that this will calculate the size of 64 bit values truncated to 32.
size_t PBComputeRawVarint32SizeForInteger(NSInteger value) __attribute__ ((const));

/**
 * Compute the number of bytes that would be needed to encode a
 * MessageSet extension to the stream.  For historical reasons,
 * the wire format differs from normal fields.
 */
size_t PBComputeMessageSetExtensionSize(int32_t fieldNumber,
                                        PBGeneratedMessage *value) __attribute__ ((const));

/**
 * Compute the number of bytes that would be needed to encode an
 * unparsed MessageSet extension field to the stream.  For
 * historical reasons, the wire format differs from normal fields.
 */
size_t PBComputeRawMessageSetExtensionSize(int32_t fieldNumber,
                                           NSData* value) __attribute__ ((const));

/**
 * Compute the number of bytes that would be needed to encode an
 * enum field, including tag.  Caller is responsible for converting the
 * enum value to its numeric value.
 */
size_t PBComputeEnumSize(int32_t fieldNumber,
                         int32_t value) __attribute__ ((const));

CF_EXTERN_C_END
