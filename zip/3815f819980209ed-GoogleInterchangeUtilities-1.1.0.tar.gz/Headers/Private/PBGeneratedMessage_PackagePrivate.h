// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// This header is private to the ProtobolBuffers library and must NOT be
// included by any sources outside this library. The contents of this file are
// subject to change at any time without notice.

#import "PBGeneratedMessage.h"

#import "PBArray_PackagePrivate.h"

@interface PBGeneratedMessage () <PBMutableArrayDelegate> {
 @package
  // A pointer to the actual fields of the subclasses. The actual structure
  // pointed to by this pointer will depend on the subclass.
  // All of the actual structures will start the same as
  // PBGeneratedMessage_Storage with _has_bits_ as the first field.
  // Kept public because static functions need to access it.
  PBGeneratedMessage_StoragePtr messageStorage_;

  // A lock to provide mutual exclusion from internal data that can be modified
  // by read operations such as getters. Used to guarantee thread safety for
  // concurrent reads on the message.
  OSSpinLock readOnlyMutex_;
}

// Returns a new instance that was automatically created by |autocreator| for
// its field |field|.
+ (instancetype)newMessageWithAutocreator:(PBGeneratedMessage *)autocreator
                                    field:(PBFieldDescriptor *)field;

// Gets an extension value without autocreating the result if not found. (i.e.
// returns nil if the extension is not set)
- (id)getExistingExtension:(PBExtensionField*)extension;

@end

CF_EXTERN_C_BEGIN

// Call this when you mutate a message. It will cause the message to become
// visible to its autocreator.
void PBBecomeVisibleToAutocreator(PBGeneratedMessage *self);

CF_EXTERN_C_END
