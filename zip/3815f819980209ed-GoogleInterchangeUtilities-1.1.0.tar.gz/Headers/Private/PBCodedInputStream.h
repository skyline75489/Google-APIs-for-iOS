// Copyright 2008 Cyrus Najmabadi
// Copyright 2011 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import <Foundation/Foundation.h>

@class PBGeneratedMessage;
@class PBExtensionRegistry;
@class PBUnknownFieldSet;

// Reads and decodes protocol message fields.
// Subclassing of PBCodedInputStream is NOT supported.
@interface PBCodedInputStream : NSObject

+ (instancetype)streamWithData:(NSData*)data;

- (instancetype)initWithData:(NSData*)data;

// Attempt to read a field tag, returning zero if we have reached EOF.
// Protocol message parsers use this to read tags, since a protocol message
// may legally end wherever a tag occurs, and zero is not a valid tag number.
- (int32_t)readTag;

- (double)readDouble;
- (float)readFloat;
- (uint64_t)readUInt64;
- (uint32_t)readUInt32;
- (int64_t)readInt64;
- (int32_t)readInt32;
- (uint64_t)readFixed64;
- (uint32_t)readFixed32;
- (int32_t)readEnum;
- (int32_t)readSFixed32;
- (int64_t)readSFixed64;
- (int32_t)readSInt32;
- (int64_t)readSInt64;
- (BOOL)readBool;
- (NSString*)readString;
- (NSData*)readData;


// Read an embedded message field value from the stream.
- (void)readMessage:(PBGeneratedMessage*)builder
    extensionRegistry:(PBExtensionRegistry*)extensionRegistry;

- (void)readGroup:(int32_t)fieldNumber
          builder:(PBGeneratedMessage*)builder
    extensionRegistry:(PBExtensionRegistry*)extensionRegistry;

// Reads a {@code group} field value from the stream and merges it into the
// given {@link UnknownFieldSet}.
- (void)readUnknownGroup:(int32_t)fieldNumber
                 builder:(PBUnknownFieldSet*)builder;

// Reads and discards a single field, given its tag value.
//
// @return {@code false} if the tag is an endgroup tag, in which case
//         nothing is skipped.  Otherwise, returns {@code true}.
//
- (BOOL)skipField:(int32_t)tag;

// Reads and discards an entire message.  This will read either until EOF
// or until an endgroup tag, whichever comes first.
- (void)skipMessage;

- (BOOL)isAtEnd;

- (size_t)pushLimit:(size_t)byteLimit;
- (void)popLimit:(size_t)oldLimit;
- (size_t)bytesUntilLimit;

- (size_t)position;

// Verifies that the last call to readTag() returned the given tag value.
// This is used to verify that a nested group ended with the correct
// end tag.
//
// @throws NSParseErrorException {@code value} does not match the last tag.
- (void)checkLastTagWas:(int32_t)value;

@end
