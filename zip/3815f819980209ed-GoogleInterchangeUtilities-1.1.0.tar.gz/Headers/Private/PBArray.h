// Protocol Buffers for Objective C
//
// Copyright 2010 Booyah Inc.
// Copyright 2011 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Author: Jon Parise <jon@booyah.com>


#import <Foundation/Foundation.h>

@class PBMutableArray;

// If this is defined, we are in a PB_PROTOCOLBUFFERS1_SUPPORT mode which
// hopefully we won't have to support very long. The major feature is that
// this allows us to assign arrays to protocol buffer fields that are
// mutable arrays.
#if PB_PROTOCOLBUFFERS1_SUPPORT
  #define PBInstanceType id
#else  // PB_PROTOCOLBUFFERS1_SUPPORT
  #define PBInstanceType instancetype
#endif  // PB_PROTOCOLBUFFERS1_SUPPORT

extern NSString * const PBArrayTypeMismatchException;
extern NSString * const PBArrayNumberExpectedException;
extern NSString * const PBArrayAllocationFailureException;

typedef enum _PBArrayValueType
{
  PBArrayValueTypeObject,
  PBArrayValueTypeBool,
  PBArrayValueTypeInt32,
  PBArrayValueTypeUInt32,
  PBArrayValueTypeInt64,
  PBArrayValueTypeUInt64,
  PBArrayValueTypeFloat,
  PBArrayValueTypeDouble,
  PBArrayValueTypeEnum = PBArrayValueTypeInt32,
} PBArrayValueType;

// PBArray is an immutable array class that's optimized for storing primitive
// values.  All values stored in an PBArray instance must have the same type
// (PBArrayValueType).  Object values (PBArrayValueTypeObject) are retained.
// PBArrays only support fast enumeration on arrays of type
// PBArrayValueTypeObject (this covers strings, data, messages etc.).
// PBArrays support enumerating types using blocks (see below to see
// types currently supported).
// Subclassing of PBArray array is NOT supported.
@interface PBArray : NSObject <NSCopying, NSMutableCopying, NSFastEnumeration>

- (NSUInteger)count;
- (id)objectAtIndex:(NSUInteger)idx;
- (id)objectAtIndexedSubscript:(NSUInteger)idx;
- (id)firstObject;
- (id)lastObject;
- (BOOL)boolAtIndex:(NSUInteger)idx;
- (int32_t)int32AtIndex:(NSUInteger)idx;
- (uint32_t)uint32AtIndex:(NSUInteger)idx;
- (int64_t)int64AtIndex:(NSUInteger)idx;
- (uint64_t)uint64AtIndex:(NSUInteger)idx;
- (float)floatAtIndex:(NSUInteger)idx;
- (double)doubleAtIndex:(NSUInteger)idx;

// Return an NSArray copy of this PBArray. Numerical types will be NSNumbers.
// This hopefully will be used rarely. You can do fast enumeration etc. on
// PBArray.
- (NSArray *)array;

#if NS_BLOCKS_AVAILABLE
// Return an NSArray of block(obj) for each item in the PBArray. Numerical types
// will be passed to the conversion block as NSNumbers. If block(obj) is nil,
// the object is skipped.
- (NSArray *)arrayWithConversion:(id (^)(id obj))block;

// PBArrays currently only support enumerating arrays of type
// PBArrayValueTypeObject and PBArrayValueTypeInt32.
// Others could be added if desired. PBArrays also support fast enumeration
// (only on arrays of type PBArrayValueTypeObject).
- (void)enumerateObjectsUsingBlock:(void (^)(id obj,
                                             NSUInteger idx,
                                             BOOL *stop))block;
- (void)enumerateInt32sUsingBlock:(void (^)(int32_t value,
                                            NSUInteger idx,
                                            BOOL *stop))block;
#endif  // NS_BLOCKS_AVAILABLE

@property (nonatomic,assign,readonly) PBArrayValueType valueType;
@property (nonatomic,assign,readonly) const void * data;
@property (nonatomic,assign,readonly) NSUInteger count;

- (PBInstanceType)arrayByAppendingArray:(PBArray *)array;

+ (PBInstanceType)arrayWithValueType:(PBArrayValueType)valueType;
+ (PBInstanceType)arrayWithValues:(const void *)values
                            count:(NSUInteger)count
                        valueType:(PBArrayValueType)valueType;
+ (PBInstanceType)arrayWithArray:(NSArray *)array
                       valueType:(PBArrayValueType)valueType;
+ (PBInstanceType)arrayWithObject:(id)object;
+ (PBInstanceType)arrayWithObjects:(id)firstObj, ... NS_REQUIRES_NIL_TERMINATION;
+ (PBInstanceType)arrayWithInt32:(int32_t)value;

// Terminate with INT32_MAX
+ (PBInstanceType)arrayWithInt32s:(int32_t)firstValue, ...;
- (PBInstanceType)initWithValueType:(PBArrayValueType)valueType;
- (PBInstanceType)initWithValues:(const void *)values
                           count:(NSUInteger)count
                       valueType:(PBArrayValueType)valueType;
- (PBInstanceType)initWithArray:(NSArray *)array
                      valueType:(PBArrayValueType)valueType;
- (PBInstanceType)initWithObject:(id)object;
- (PBInstanceType)initWithInt32:(int32_t)value;

// NSKeyValueCoding support - Like NSArray, BUT no collection support, i.e. -
// @sum.foo, etc. are NOT supported.
//
// Return an NSArray containing the results of invoking -valueForKey: on each
// item in the array. If an item returns NULL, NSNull will be inserted in the
// array. Throws if the value type isn't PBArrayValueTypeObject.
- (id)valueForKey:(NSString *)key;
// Invokes -setValue:forKey: on each item in the array. Throws if the value
// type isn't PBArrayValueTypeObject.
- (void)setValue:(id)value forKey:(NSString *)key;
@end

// PBMutableArray extends PBArray with the ability to append new values to
// the end of the array.
// Subclassing of PBMutableArray array is NOT supported.
@interface PBMutableArray : PBArray

+ (PBInstanceType)arrayWithValueType:(PBArrayValueType)valueType
                            capacity:(NSUInteger)numItems;
- (PBInstanceType)initWithValueType:(PBArrayValueType)valueType
                           capacity:(NSUInteger)numItems;

// Replaces content of self with content of array. self and array must have
// the same type internally (eg both be UInt32 arrays).
- (void)setArray:(PBArray *)array;
- (void)addObject:(id)value;
- (void)addBool:(BOOL)value;
- (void)addInt32:(int32_t)value;
- (void)addUInt32:(uint32_t)value;
- (void)addInt64:(int64_t)value;
- (void)addUInt64:(uint64_t)value;
- (void)addFloat:(float)value;
- (void)addDouble:(double)value;

- (void)replaceObjectAtIndex:(NSUInteger)idx withObject:(id)value;
- (void)setObject:(id)value atIndexedSubscript:(NSUInteger)idx;
- (void)replaceBoolAtIndex:(NSUInteger)idx withBool:(BOOL)value;
- (void)replaceInt32AtIndex:(NSUInteger)idx withInt32:(int32_t)value;
- (void)replaceUInt32AtIndex:(NSUInteger)idx withUInt32:(uint32_t)value;
- (void)replaceInt64AtIndex:(NSUInteger)idx withInt64:(int64_t)value;
- (void)replaceUInt64AtIndex:(NSUInteger)idx withUInt64:(uint64_t)value;
- (void)replaceFloatAtIndex:(NSUInteger)idx withFloat:(float)value;
- (void)replaceDoubleAtIndex:(NSUInteger)idx withDouble:(double)value;

- (void)appendArray:(PBArray *)array;
- (void)appendValues:(const void *)values
           valueType:(PBArrayValueType)valueType
               count:(NSUInteger)count;
- (void)removeAllValues;
@end
