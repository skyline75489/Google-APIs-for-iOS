// Copyright 2008 Cyrus Najmabadi
// Copyright 2011 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import <Foundation/Foundation.h>

@class PBUnknownFieldSet;
@class PBCodedOutputStream;
@class PBCodedInputStream;
@class PBField;

@interface PBUnknownFieldSet : NSObject <NSCopying, NSMutableCopying>

+ (BOOL)isFieldTag:(int32_t)tag;

- (NSData*)data;

- (BOOL)hasField:(int32_t)number;
- (PBField*)getField:(int32_t)number;
- (NSUInteger)countOfFields;

- (size_t)serializedSize;
- (size_t)serializedSizeAsMessageSet;

- (void)writeToCodedOutputStream:(PBCodedOutputStream*)output;
- (void)writeAsMessageSetTo:(PBCodedOutputStream*)output;

- (void)mergeUnknownFields:(PBUnknownFieldSet*)other;

- (void)mergeFromCodedInputStream:(PBCodedInputStream*)input;
- (void)mergeFromData:(NSData*)data;

- (void)mergeVarintField:(int32_t)number value:(int32_t)value;
- (BOOL)mergeFieldFrom:(int32_t)tag input:(PBCodedInputStream*)input;
- (void)mergeMessageSetMessage:(int32_t)number data:(NSData *)messageData;

- (void)addField:(PBField*)field;

// Returns an NSArray of the PBFields sorted by the field numbers.
- (NSArray *)sortedFields;

@end
