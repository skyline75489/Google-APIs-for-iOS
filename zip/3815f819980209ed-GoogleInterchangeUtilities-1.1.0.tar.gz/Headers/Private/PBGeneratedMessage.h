// Copyright 2008 Cyrus Najmabadi
// Copyright 2011 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// PBGeneratedMessage is safe for multiple simultaneous reads on multiple
// threads. This includes accessing all types of fields and their "has" state.
// Setting or clearing fields remains non thread safe. Note that making a copy
// or merging one message into another are both SHALLOW operations. This means
// that all message type fields in the copy refer to the same object as the
// original and cannot be mutated concurrently.

#import <libkern/OSAtomic.h>

#import "PBRootObject.h"

@class PBDescriptor;
@class PBCodedInputStream;
@class PBCodedOutputStream;
@class PBFieldDescriptor;
@class PBUnknownFieldSet;
typedef struct PBGeneratedMessage_Storage *PBGeneratedMessage_StoragePtr;

// In DEBUG ONLY, an NSException is thrown when a parsed message doesn't
// contain required fields. This key allows you to retrieve the parsed message
// from the exception's |userInfo| dictionary.
#ifdef DEBUG
extern NSString *const PBExceptionMessageKey;
#endif  // DEBUG

// NOTE:
// If you add a instance method/property to this class that may conflict with
// methods declared in protos, you need to update objective_helpers.cc.
// The main cases are methods that take no arguments, or setFoo:/hasFoo: type
// methods.
@interface PBGeneratedMessage : PBRootObject <NSCopying,
                                              NSMutableCopying,
                                              NSSecureCoding>

@property(nonatomic, retain) PBUnknownFieldSet *unknownFields;

// Are all required fields in the message and all embedded messages set.
@property(nonatomic, readonly, getter=isInitialized) BOOL initialized;

// Returns an autoreleased instance.
+ (instancetype)message;

// Serializes the message and writes it to output.
- (void)writeToCodedOutputStream:(PBCodedOutputStream*)output;
- (void)writeToOutputStream:(NSOutputStream*)output;

// Serializes the message and writes it to output, but writes the size of the
// message as a variant before writing the message.
- (void)writeDelimitedToCodedOutputStream:(PBCodedOutputStream*)output;
- (void)writeDelimitedToOutputStream:(NSOutputStream*)output;

// Serializes the message to an NSData. Note that this value is not cached, so
// if you are using it repeatedly, cache it yourself.
// In DEBUG ONLY:
// @throws NSInternalInconsistencyException The message is missing one or more
//         required fields (i.e. -[isInitialized] returns false). Use
//         PBExceptionMessageKey to retrieve the message from |userInfo|.
- (NSData*)data;

// Same as -[data], except a delimiter is added to the start of the data
// indicating the size of the message data that follows.
- (NSData*)delimitedData;

// Returns the size of the object if it were serialized.
// This is not a cached value. If you are following a pattern like this:
// size_t size = [aMsg serializedSize];
// NSMutableData *foo = [NSMutableData dataWithCapacity:size + sizeof(size)];
// [foo writeSize:size];
// [foo appendData:[aMsg data]];
// you would be better doing:
// NSData *data = [aMsg data];
// NSUInteger size = [aMsg length];
// NSMutableData *foo = [NSMutableData dataWithCapacity:size + sizeof(size)];
// [foo writeSize:size];
// [foo appendData:data];
- (size_t)serializedSize;

// Create a message based on a variety of inputs.
// In DEBUG ONLY
// @throws NSInternalInconsistencyException The message is missing one or more
//         required fields (i.e. -[isInitialized] returns false). Use
//         PBExceptionMessageKey to retrieve the message from |userInfo|.
+ (instancetype)parseFromData:(NSData*)data;
+ (instancetype)parseFromData:(NSData*)data
            extensionRegistry:(PBExtensionRegistry*)extensionRegistry;
+ (instancetype)parseFromCodedInputStream:(PBCodedInputStream*)input
                        extensionRegistry:(PBExtensionRegistry*)extensionRegistry;

// Create a message based on delimited input.
+ (instancetype)parseDelimitedFromCodedInputStream:(PBCodedInputStream*)input
                                 extensionRegistry:(PBExtensionRegistry*)extensionRegistry;

// Return the descriptor for the message
+ (PBDescriptor *)descriptor;
- (PBDescriptor *)descriptor;

- (BOOL)hasExtension:(PBExtensionField*)extension;
- (id)getExtension:(PBExtensionField*)extension;
- (NSArray *)extensionsCurrentlySet;  // array of id<PBExtensionField>

// Extendable Message Builder
- (void)setExtension:(PBExtensionField*)extension value:(id)value;
- (void)addExtension:(PBExtensionField*)extension value:(id)value;
- (void)setExtension:(PBExtensionField*)extension
               index:(NSUInteger)index
               value:(id)value;
- (void)clearExtension:(PBExtensionField*)extension;

// Resets all fields to their default values.
- (void)clear;

// Clear the autocreator, if any. Asserts if the autocreator still has an
// autocreated reference to this message.
- (void)clearAutocreator;

// Merge some unknown fields into the message.
- (void)mergeUnknownFields:(PBUnknownFieldSet*)unknownFields;

// Returns an array of PBExtensionField* for all the extensions currently
// in use on the message.  They are sorted by field number.
- (NSArray *)sortedExtensionsInUse;

// Parses a message of this type from the input and merges it with this
// message.
//
// Warning:  This does not verify that all required fields are present in
// the input message.
// Note:  The caller should call
// -[CodedInputStream checkLastTagWas:] after calling this to
// verify that the last tag seen was the appropriate end-group tag,
// or zero for EOF.
- (void)mergeFromCodedInputStream:(PBCodedInputStream*)input
                extensionRegistry:(PBExtensionRegistry*)extensionRegistry;
- (void)mergeFromData:(NSData*)data
    extensionRegistry:(PBExtensionRegistry*)extensionRegistry;
- (void)mergeFrom:(PBGeneratedMessage*)other;

// Parses the next delimited message of this type from the input and merges it
// with this message.
- (void)mergeDelimitedFromCodedInputStream:(PBCodedInputStream*)input
                         extensionRegistry:(PBExtensionRegistry*)extensionRegistry;

// Returns whether |message| autocreated this message. This is NO if the message
// was not autocreated by |message| or if it has been mutated since autocreation.
- (BOOL)wasAutocreatedBy:(PBGeneratedMessage *)message;

#if PB_PROTOCOLBUFFERS1_SUPPORT

// The following three methods are stop gaps to help with trying to bridge
// Protobuffers and Protobuffers2. They will be removed as soon as possible.
+ (instancetype)builder;
- (instancetype)builder;
- (instancetype)build;

#endif  // PB_PROTOCOLBUFFERS1_SUPPORT

@end
