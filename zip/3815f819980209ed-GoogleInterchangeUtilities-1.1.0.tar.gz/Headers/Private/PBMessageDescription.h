// Copyright 2011 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import "PBTypes.h"

@class PBFieldOptions;
@class PBGeneratedMessage;

// Describes attributes of the field.
typedef NS_OPTIONS(uint32_t, PBFieldFlags) {
  // These map to standard protobuf attributes.
  PBFieldRequired = 1 << 1,
  PBFieldRepeated = 1 << 2,
  PBFieldPacked = 1 << 3,
  PBFieldOptional = 1 << 4,

  // These are not standard protobuf attributes.
  //
  // Indicates the field has a default value.
  PBFieldHasDefaultValue = 1 << 20,
  // Indicates the field needs custom handling for the TextFormat name, if not
  // set, the name can be derived from the ObjC name.
  PBFieldTextFormatNameCustom = 1 << 21,
  // Indicates the field has an enum descriptor.
  PBFieldHasEnumDescriptor = 1 << 22,
};

// Function used to verify that a given value can be represented by an
// enum type.
typedef BOOL(*PBEnumVerificationFunc)(int);

// Describes a single field in a protobuf as it is represented as an ivar.
typedef struct PBMessageFieldDescription {
  // Name of ivar.
  const char *name;
  // The field number for the ivar.
  uint32_t number;
  // The index (in bits) into _has_bits_ for determining if ivar is set
  uint32_t hasIndex;
  // Field flags. Use accessor functions below.
  PBFieldFlags flags;
  // Type of the ivar.
  PBType type;
  // Offset of the variable into it's structure struct.
  size_t offset;
  // FieldOptions protobuf, serialized as string.
  const char *fieldOptions;

  PBValue defaultValue;  // Default value for the ivar.
  union {
    // For enums only:
    // If (flags & PBFieldHasEnumDescriptor) then it will be a className,
    // otherwise it will be an enumVerifier.
    const char *className;  // Name for message class or enum class.
    PBEnumVerificationFunc enumVerifier;
  } typeSpecific;
} PBMessageFieldDescription;

// Describes an enum type defined in a .proto file.
typedef struct PBMessageEnumDescription {
  // The name of this enum type in the containing scope.
  const char *name;
} PBMessageEnumDescription;

// Describes an individual enum constant of a particular type.
typedef struct PBMessageEnumValueDescription {
  // Name of this enum constant.
  const char *name;
  // Numeric value of this enum constant.
  int32_t number;
} PBMessageEnumValueDescription;

// An extensions range.
typedef struct PBMessageExtensionRangeDescription {
  uint32_t start;
  uint32_t end;
} PBMessageExtensionRangeDescription;

// Describes attributes of the extension.
typedef NS_OPTIONS(uint32_t, PBExtensionOptions) {
  PBExtensionRepeated = 1 << 2,
  PBExtensionPacked = 1 << 3,
  PBExtensionSetWireFormat = 1 << 4,
};

// An extension
typedef struct PBExtensionDescription {
  const char *singletonName;
  PBType type;
  const char *extendedClass;
  int32_t fieldNumber;
  PBValue defaultValue;
  const char *messageOrGroupBuilderClass;
  PBExtensionOptions options;
  const char *enumName;
} PBExtensionDescription;
