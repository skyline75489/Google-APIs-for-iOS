// Copyright 2011 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import <Foundation/Foundation.h>

#import "PBBootstrap.h"

@class PBGeneratedMessage;
@class PBArray;

// A union for storing all possible Protobuf values.
// Note that owner is responsible for memory management of object types.
typedef union {
  BOOL valueBool;
  uint32_t valueFixed32;
  int32_t valueSFixed32;
  float valueFloat;
  uint64_t valueFixed64;
  int64_t valueSFixed64;
  double valueDouble;
  int32_t valueInt32;
  int64_t valueInt64;
  int32_t valueSInt32;
  int64_t valueSInt64;
  uint32_t valueUInt32;
  uint64_t valueUInt64;
  NS_UNSAFE_UNRETAINED NSData *valueData;
  NS_UNSAFE_UNRETAINED NSString *valueString;
  NS_UNSAFE_UNRETAINED PBGeneratedMessage *valueMessage;
  NS_UNSAFE_UNRETAINED PBGeneratedMessage *valueGroup;
  int32_t valueEnum;

  // Special types for dealing with arrays and generic objects
  NS_UNSAFE_UNRETAINED PBArray *valueArray;
  NS_UNSAFE_UNRETAINED id valueObject;
} PBValue;

// Do not change the order of this enum (or add things to it) without thinking
// about it very carefully. There are several things that depend on the order.
typedef enum {
  PBTypeBool = 0,
  PBTypeFixed32,
  PBTypeSFixed32,
  PBTypeFloat,
  PBTypeFixed64,
  PBTypeSFixed64,
  PBTypeDouble,
  PBTypeInt32,
  PBTypeInt64,
  PBTypeSInt32,
  PBTypeSInt64,
  PBTypeUInt32,
  PBTypeUInt64,
  PBTypeData,  // Maps to Bytes Protobuf type
  PBTypeString,
  PBTypeMessage,
  PBTypeGroup,
  PBTypeEnum,
} PBType;

enum {
  // A count of the number of types in PBType. Separated out from the PBType
  // enum to avoid warnings regarding not handling PBTypeCount in switch
  // statements.
  PBTypeCount = PBTypeEnum + 1
};
